~~< Nadeoki's Config ver. 1.9 >~~
`````````````````````````````````
get latest version here: https://github.com/nadeoki/tf2

1. How to Use:
		place the zip inside of SteamLibrary\steamapps\common\Team Fortress 2\tf\custom
		then unzip. Feel free to rename it but leave everything inside it as is.

		Look at the Github for important configuration info.
		as well as inside. 
		\steamapps\common\Team Fortress 2\tf\custom\nadeoki's config 1.9\cfg\autoexec.cfg
		and \steamapps\common\Team Fortress 2\tf\custom\nadeoki's config 1.9\cfg\gfx.cfg

2. make sure to choose a dxlevel based on the github's guide!

if you read the github and every other available resource here and have unresolved
questions. @nadeoki on discord or open an issue on github https://github.com/nadeoki/tf2/issues

3. add the following to Tf2 Startoptions on Steam (example)
I currently use these settings for borderless windowed mode 

-noborder -window -console -novid -no_texture_stream -nosteamcontroller -noforcemspd -nojoy -noff -nohltv
 

!!IMPORTANT(make sure to disable fullscreen optimization in the application's property options on windows)


4. you can add keybinds to binds.cfg to make sure they execute.

gfx.cfg includes most of the crucial commands for Visual Graphics and optimizations to network.
change at your own risk.

5. Included is also an optional tfdb plugin for a snowball effect that helps with visual clarity on 
tf dodgeball.
Make sure to remove the files before playing on servers that are SVT Pure 1, it breaks on those.

For Dodgeball!

Unzip the tfdb.tar file using 7Zip.
It contains the Snowball mod for the Rocket, note that the files break casual tf2.
So before you join casual tf2, make sure to delete the files that you extracted.
You can keep the .tar itself there so you can easily get them back for dodgeball

The Sound folder inside \nadeoki's config 1.9\sound\ 
contains muted sounds for Dodgeball specific gameplay. It is a bit annoying on servers that don't mute the Announcer.